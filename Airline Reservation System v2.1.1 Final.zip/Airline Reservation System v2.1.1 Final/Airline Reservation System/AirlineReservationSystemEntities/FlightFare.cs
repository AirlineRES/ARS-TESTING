﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
   public class FlightFare
    {
        public int FlightId { get; set; }
        public decimal Fare { get; set; }
        public int seats { get; set; }
        public string FlightClass { get; set; }

    }
}
