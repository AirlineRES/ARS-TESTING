﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
    public class RevenueOverall
    {
       

        private int _totalSpecified;
        public int TotalSpecified
        {
            get
            {
                return _totalSpecified;
            }
            set

            {
                _totalSpecified = value;
            }
        }
    }
}
