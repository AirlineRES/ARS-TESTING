﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AirlineReservationSystemEntities
{
   public class FlightRevenue
    {
        private int id;
        private int _total;

        public int flightID
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }

        public int TotalRevenue
        {
            get
            {
                return _total;
            }
            set

            {
                _total = value;
            }
        }
    }
}
