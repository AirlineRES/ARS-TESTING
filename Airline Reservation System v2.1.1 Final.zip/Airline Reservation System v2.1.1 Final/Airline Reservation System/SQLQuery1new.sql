﻿select * from airline.FlightClass

select * from airline.Flights

select * from airline.Reservation

declare @result int;
exec @result= [airline].[USP_CLASSBOOKING] 109,'First Class' ,'1/02/2019'

--exec sp_helptext '[airline].[USP_CLASSBOOKING]'
print @result



insert into airline.FlightClass values ('101','Business Class',20000,15),('101','First Class',22000,15),('101','Economy Class',25000,15)

drop proc [airline].[USP_CLASSBOOKING] ;

create proc [airline].[USP_CLASSBOOKING]  
( @flightID varchar(10),  
@flightClass varchar(20), 
@journeyDate date,
@noOfPassengers int
)  
  
 As  
 declare @classcnt int  
 declare @tickets int  
 declare @seats int  
  
 BEGIN  
 Set @tickets = 0
 Set @seats = 0

  select  @tickets=  sum(noOfTickets) from airline.reservation where FlightID=@flightID and Class = @flightClass and ReservationStatus = 'Booked' and JourneyDate = @journeyDate
select @seats = TotalSeats from airline.FlightClass where FlightID=@flightID and Class = @flightClass  
  
if(@tickets >= @seats )  
begin  
return 0  
end  
else if ((@seats - @tickets) < @noOfPassengers)
begin  
return 0  
end  
else 
begin  
return 1
end  

 
  
 END

 Declare @seats int
set @seats = 0
  -- select   sum(noOfTickets) from airline.reservation where FlightID=25649 and Class = 'First Class' and ReservationStatus = 'Booked'  
 select @seats = sum(noOfTickets) from airline.reservation where FlightID=1029 and Class = 'First Class' and ReservationStatus = 'Booked' and JourneyDate = '05/21/2019'

print @seats