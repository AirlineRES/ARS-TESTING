﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace AirlineReservationSystemExceptions
{
    public class AirlineException:ApplicationException
    {
        public AirlineException()
           : base()
        {
        }
        public AirlineException(string msg)
            : base(msg)
        {
        }
    }
}
