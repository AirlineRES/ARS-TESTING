﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for AdminLogin.xaml
    /// </summary>
    public partial class AdminLogin : Window
    {
        public AdminLogin()
        {
            InitializeComponent();
        }
        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (txtAdminId.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Admin ID...!!!");
                isValid = false;
            }

            if (txtPwbAdmin.Password.Length == 0)
            {
                sb.Append("\nPlease Enter Password...!!!");
                isValid = false;
            }
            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }

            return isValid;
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Validation())
                {
                    bool loggedIn = false;
                    string username, password;

                    username = txtAdminId.Text;
                    password = txtPwbAdmin.Password.ToString();

                    loggedIn = TicketBL.LoginUserBL(username, password);
                    if (loggedIn)
                    {
                        AdminWindow adminWindow = new AdminWindow();
                        adminWindow.Show();
                        this.Close();
                        MessageBox.Show("Welcome");
                    }
                    else
                        MessageBox.Show("User Invalid");
                }
            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }



        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            txtAdminId.Text = "";
            txtPwbAdmin.Clear();
        }
    }
}
