﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        IEnumerable<Flight> flights = null;
        public HomePage()
        {
            InitializeComponent();
        }

        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (dpTravelDate.Text.Length == 0)
            {
                isValid = false;
                MessageBox.Show("Please Enter Travel Date");
            }

            if (dpReturnDate.Text.Length == 0)
            {
                isValid = false;
                //sb.Append(Environment.NewLine + "Please Enter Return Date");
                MessageBox.Show("Please Enter Return Date");
            }

            if (txtSource.Text.Length == 0)
            {
                isValid = false;
                MessageBox.Show("Please Enter Source");
            }

            if (txtDestination.Text.Length == 0)
            {
                isValid = false;
                MessageBox.Show("Please Enter Destination");
            }

            return isValid;
        }

        private void btnViewTicket_Click(object sender, RoutedEventArgs e)
        {
            ViewTicket viewTicket = new ViewTicket();
            viewTicket.Show();
            this.Close();
        }

        private void btnAboutUs_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnContactUs_Click(object sender, RoutedEventArgs e)
        {
            
        }

        public void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (Validation())
                {

                   flights = FlightBL.ViewFlightsBL(txtSource.Text, txtDestination.Text);
                    dgFlight.ItemsSource = flights;
                    dgFlight.Visibility = Visibility.Visible;
                   
                    
                }
             }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnAdminLogin_Click(object sender, RoutedEventArgs e)
        {
            AdminLogin adminLogin = new AdminLogin();
            adminLogin.Show();
            this.Close();
        }

        private void BtnBook_Click(object sender, RoutedEventArgs e)
        {
            BookTicket home = new BookTicket();
            home.DataContext = flights;
            home.dpJourneyDate.Text = dpTravelDate.Text; 
            home.Show();

        }
    }
}
