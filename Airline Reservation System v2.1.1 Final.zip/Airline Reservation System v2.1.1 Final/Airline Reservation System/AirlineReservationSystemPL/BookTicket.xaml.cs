﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;


namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for BookTicket.xaml
    /// </summary>
    public partial class BookTicket : Window
    {
        public BookTicket()
        {
            InitializeComponent();
        }

        private void BtnBook_Click(object sender, RoutedEventArgs e)
        {
            BookTicketPL();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            DisplayClass();
        }
        public void DisplayClass()
        {
            try
            {
                IEnumerable<FlightFare> flightFares = FlightBL.GetFlightClass(Convert.ToInt32(txtFlightID.Text));
                cbClass.ItemsSource = flightFares;
                cbClass.DisplayMemberPath = "FlightClass";
                
             

            }
            catch (AirlineException ps)
            {
                MessageBox.Show(ps.Message);
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);

            }

        }
        public void BookTicketPL()
        {
            try
            {
                
                Reservation ticket = new Reservation();

                ticket.FlightId = txtFlightID.Text;
                ticket.DateofBooking = DateTime.Now.Date.ToString();
                ticket.JourneyDate = dpJourneyDate.Text;// Journery Date not Specified
                ticket.PassengerName = txtBookName.Text;
                ticket.ContactNo = txtBookContact.Text;
                ticket.Email = txtBookemail.Text;
                ticket.NoofTickets = Convert.ToInt32(txtBookPassengers.Text);
                ticket.Age = Convert.ToInt32(txtAge.Text); // Age no specified
                //ComboBoxItem cmb = (ComboBoxItem)cbClass.SelectedItem;
                FlightFare flightFare = (FlightFare)cbClass.SelectedItem;
                ticket.Class = flightFare.FlightClass;

                if (rbBookMale.IsChecked == true)
                    ticket.Gender = rbBookMale.Content.ToString();
                else
                    ticket.Gender = rbBookFemale.Content.ToString();



                string ticketNo = TicketBL.BookTicketBL(ticket);
                if (ticketNo != "NA")
                {
                    MessageBox.Show("Your Ticket No. : " + ticketNo + "Total Fare is :" + ticket.NoofTickets * Convert.ToInt32(txtFare.Text));
                }
                else
                    MessageBox.Show("No seats Or Less Seats Available");

            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

    }
}
