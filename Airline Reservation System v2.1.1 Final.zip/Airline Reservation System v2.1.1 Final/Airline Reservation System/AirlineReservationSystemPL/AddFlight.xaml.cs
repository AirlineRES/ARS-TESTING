﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AirlineReservationSystemBL;
using AirlineReservationSystemEntities;
using AirlineReservationSystemExceptions;

namespace AirlineReservationSystemPL
{
    /// <summary>
    /// Interaction logic for AddFlight.xaml
    /// </summary>
    public partial class AddFlight : Window
    {
        public AddFlight()
        {
            InitializeComponent();
        }

        public bool Validation()
        {
            StringBuilder sb = new StringBuilder();
            bool isValid = true;

            if (txtID.Text.Length == 0)
            {
                sb.Append("Please Enter Flight Id...!!!");
                isValid = false;
            }

            if (txtLaunchDate.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Launch Date...!!!");
                isValid = false;
            }

            if (txtSource.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Source...!!!");
                isValid = false;
            }

            if (txtDestination.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Destination...!!!");
                isValid = false;
            }

            if (txtDepartureTime.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Destination Time...!!!");
                isValid = false;
            }
            if (txtArrivalTime.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Arrival Time...!!!");
                isValid = false;
            }
            if (txtNoOfSeats.Text.Length == 0)
            {
                sb.Append("\nPlease Enter Number Of Seats...!!!");
                isValid = false;
            }

            if (cbFirstClass.IsChecked == false || cbBusinessClass.IsChecked == false || cbEconomyClass.IsChecked == false)
            {
                sb.Append("\nPlease Select Classes...!!!");
                isValid = false;
            }

            if (!isValid)
            {
                throw new Exception(sb.ToString());
            }

            return isValid;
        }




        private void BtnAddFlight_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                bool isAdded = false;
                if (Validation())
                {
                    Flight flight = new Flight();

                    flight.FlightID = Convert.ToInt32(txtID.Text);
                    flight.LaunchDate = Convert.ToDateTime(txtLaunchDate.Text);
                    flight.Origin = txtSource.Text;
                    flight.Destination = txtDestination.Text;
                    flight.DeptTime = txtDepartureTime.Text;
                    flight.ArrivalTime = txtArrivalTime.Text;
                    flight.NoOfSeats = Convert.ToInt32(txtNoOfSeats.Text);
                    isAdded = FlightBL.InsertFlightBL(flight);
                    isAdded = FlightBL.InsertFlightClassBL( flight.FlightID,Convert.ToInt32(txtFClassSeats.Text), Convert.ToDecimal(txtFClassFare.Text), Convert.ToInt32(txtEClassSeats.Text), Convert.ToDecimal(txtEClassFare.Text), Convert.ToInt32(txtBClassSeats.Text), Convert.ToDecimal(txtBClassFare.Text),Convert.ToInt32(txtNoOfSeats.Text));
                    txtID.Clear();
                    txtNoOfSeats.Clear();
                    txtSource.Clear();
                    txtDestination.Clear();
                    txtDepartureTime.Clear();
                    txtArrivalTime.Clear();
                    txtNoOfSeats.Clear();

                }
                if (isAdded)
                    MessageBox.Show("Flight Added Successfully :)");
           
            }
            catch (AirlineException ae)
            {
                MessageBox.Show(ae.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void CbFirstClass_Checked(object sender, RoutedEventArgs e)
        {
            txtFClassFare.Visibility = Visibility.Visible;
            txtFClassSeats.Visibility = Visibility.Visible;
        }

        private void CbBusinessClass_Checked(object sender, RoutedEventArgs e)
        {
            txtBClassFare.Visibility = Visibility.Visible;
            txtBClassSeats.Visibility = Visibility.Visible;

        }

        private void CbEconomyClass_Checked(object sender, RoutedEventArgs e)
        {
            txtEClassFare.Visibility = Visibility.Visible;
            txtEClassSeats.Visibility = Visibility.Visible;

        }

        private void CbFirstClass_Unchecked(object sender, RoutedEventArgs e)
        {
            txtFClassFare.Visibility = Visibility.Hidden;
            txtFClassSeats.Visibility = Visibility.Hidden;
        }

        private void CbEconomyClass_Unchecked(object sender, RoutedEventArgs e)
        {
            txtEClassFare.Visibility = Visibility.Hidden;
            txtEClassSeats.Visibility = Visibility.Hidden;
        }

        private void CbBusinessClass_Unchecked(object sender, RoutedEventArgs e)
        {
            txtBClassFare.Visibility = Visibility.Hidden;
            txtBClassSeats.Visibility = Visibility.Hidden;
        }
    }
}
